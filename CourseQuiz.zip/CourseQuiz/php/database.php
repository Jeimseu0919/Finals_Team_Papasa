<?php
$host = 'localhost';
$name = 'myquiz';
$username = 'root';
$password = '';

$conn = new mysqli($host, $username, $password, $name);

if($conn->connect_error){
    printf("Connection failed: %s\n, $conn->connect_error");
    exit();
}
?>