<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>MyQuiz</title>
    <link rel="stylesheet" href="../../css/main.css">
</head>
<body>
<div class="navbar">
	<h3 class="center">MyQuiz</h3>
</div>
<form method="POST" action="save_score.php" >
<?php 
        include 'database.php';
        if(isset($_POST['js_mc'])) {
            $name = $_POST['name'];
            $query = "SELECT * FROM js_mc";
            $result = $conn->query($query);
		
            echo '<div class="profile-card">';
            echo '<div class="profile-container">';
            echo '<h2 class="profile-title center" name="username" value="'.$name.'">'.$name.'</h2>';
			echo 'Score: <label id="scorelbl"></label>'.'/'.mysqli_num_rows($result).'</label>'; 
			echo '<input type="hidden" value="" id="thescore" name="thescore">';
			echo '<input type="hidden" value="'.$name.'" id="thename" name="thename">';
			echo '<input type="submit" id="submit" style="display:none">';
            echo '</div>';
            echo '</div>';
			echo '</form>';
            if($result->num_rows > 0) {
                while($data = mysqli_fetch_assoc($result)) {
                    $id = $data['id'];
                    $question = $data['question'];
                    $temp_answer1 = $data['answer1'];
                    $temp_answer2 = $data['answer2'];
                    $temp_answer3 = $data['answer3'];
                    $correct_answer = $data['correct_answer'];
					$correct_answer_text = htmlentities($data['correct_answer_text']);
                    $answer1 = htmlentities($temp_answer1);
                    $answer2 = htmlentities($temp_answer2);
                    $answer3 = htmlentities($temp_answer3);
                    echo '<div class="quiz-card">';
                    echo '<div class="quiz-container">';
                    echo '<h4><b>'.$id.'.&nbsp;&nbsp;'.$question.'</b></h4> ';

                    if (isset($answer1)) {
                    echo '<input type="radio" class="button" name="'.$id.'" id="1" value="1">'.$answer1.'';
                    }

                    if (isset($answer1)) {
                    echo '<input type="radio" class="button" name="'.$id.'" id="2" value="2">'.$answer2.'';
                    }

                    if (isset($answer1)) {
                    echo '<input type="radio" class="button" name="'.$id.'" id="3" value="3">'.$answer3.'';
                    }

                    echo '<br>';
                    echo '<br>';

                    echo '<label class="ans"><b>Correct Answer:</b> '.$correct_answer_text.'</label>';
					
                    echo '<input type="hidden" class="correct" value="'.$correct_answer.'" name="'.$id.'">';
                    echo '</div>';
                    echo '</div>';
					
					
                }
            }
            echo '<input type="hidden"  name="username" value="'.$name.'">';
            echo '<input type="submit" id="submitbtn" class="submit" name="submit_quiz" onclick="check_a()" value="Submit Quiz">';
			echo '<input type="hidden" id="score" value="0">';
        }
		
		else if(isset($_POST['js_id'])) {
            $name = $_POST['name'];
            $query = "SELECT * FROM js_id";
            $result = $conn->query($query);

            echo '<div class="profile-card">';
            echo '<div class="profile-container">';
            echo '<h2 class="profile-title center" name="username" value="'.$name.'">'.$name.'</h2>';
			echo 'Score: <label id="scorelbl"></label>'.'/'.mysqli_num_rows($result).'</label>'; 
			echo '<input type="hidden" value="" id="thescore">';
			echo '<input type="submit" id="submit" style="display:none">';
            echo '</div>';
            echo '</div>';
			echo '</form>';
            if($result->num_rows > 0) {
                while($data = mysqli_fetch_assoc($result)) {
                    $id = $data['id'];
                    $question = $data['question'];
                    $answer = htmlentities($data['answer']);
                    echo '<div class="quiz-card">';
                    echo '<div class="quiz-container">';
                    echo '<h4><b>'.$id.'.&nbsp;&nbsp;'.$question.'</b></h4> ';

                    echo '<input type="input" class="input" name="'.$id.'" id="1" >';


                    echo '<br>';
                    echo '<br>';

                    echo '<label class="ans"><b>Correct Answer:</b> '.$answer.'</label>';
					
                    echo '<input type="hidden" class="correct" value="'.$answer.'" name="'.$id.'">';
                    echo '</div>';
                    echo '</div>';
					
					
                }
            }
            echo '<input type="hidden"  name="username" value="'.$name.'">';
            echo '<input type="submit" id="submitbtn" class="submit" name="submit_quiz" onclick="check_b()" value="Submit Quiz">';
			echo '<input type="hidden" id="score" value="0">';
        } 
		
		else if(isset($_POST['js_tf'])) {
            $name = $_POST['name'];
            $query = "SELECT * FROM js_tf";
            $result = $conn->query($query);

            echo '<div class="profile-card">';
            echo '<div class="profile-container">';
            echo '<h2 class="profile-title center" name="username" value="'.$name.'">'.$name.'</h2>';
			echo 'Score: <label id="scorelbl"></label>'.'/'.mysqli_num_rows($result).'</label>'; 
			echo '<input type="hidden" value="" id="thescore">';
			echo '<input type="submit" id="submit" style="display:none">';
            echo '</div>';
            echo '</div>';
			echo '</form>';
            if($result->num_rows > 0) {
                while($data = mysqli_fetch_assoc($result)) {
                    $id = $data['id'];
                    $question = $data['question'];
                    $answer = htmlentities($data['answer']);
                    
                    echo '<div class="quiz-card">';
                    echo '<div class="quiz-container">';
                    echo '<h4><b>'.$id.'.&nbsp;&nbsp;'.$question.'?</b></h4> ';

                  
                    echo '<input type="radio" class="button" name="'.$id.'" id="1" value="true">True';
                  
                    echo '<input type="radio" class="button" name="'.$id.'" id="0" value="false">False';
                    

                    echo '<br>';
                    echo '<br>';

                    echo '<label class="ans"><b>Correct Answer:</b> '.$answer.'</label>';
					
                    echo '<input type="hidden" class="correct" value="'.$answer.'" name="'.$id.'">';
                    echo '</div>';
                    echo '</div>';
					
					
                }
            }
            echo '<input type="hidden"  name="username" value="'.$name.'">';
            echo '<input type="submit" id="submitbtn" class="submit" name="submit_quiz" onclick="check_a()" value="Submit Quiz">';
			echo '<input type="hidden" id="score" value="0">';
        }
        
    ?>
    

<script>
	window.onload = function(){
		var ans = document.getElementsByClassName('ans');
		for(i = 0; i!=ans.length;i++){
			ans[i].style='display:none';
		}
		
		document.getElementById('submit').style="display:none";
		
	};
	
	// to check multiple choice and true or false
    function check_a(){
		
		var ans = document.getElementsByClassName('ans');
		for(i = 0; i!=ans.length;i++){
			ans[i].style='display:block';
		}
		
        var answers = document.getElementsByClassName('button');
		var correct = document.getElementsByClassName('correct');
		var selected = [];
		var score = 0;

        for(i = 0; i != answers.length; i++){
            if(answers[i].checked){
				selected.push(answers[i].value);
				
			}
        }
		
		
		for(i = 0; i != correct.length; i++){
			if(correct[i].value == selected[i]){
					score++;
			}
		}
		document.getElementById('score').value = score;
		document.getElementById('thescore').value = score;
		document.getElementById('scorelbl').innerHTML = score;
		document.getElementById('submitbtn').style = 'display:none';
		
		document.getElementById('submit').style="display:block";
		
    }
	
	function check_b(){
		
		var ans = document.getElementsByClassName('input');
		var correct = document.getElementsByClassName('correct');
		var score = 0;
		
		for(i = 0; i != correct.length; i++){
			if(ans[i].value == correct[i].value){
				score++;
			}
		}
		
		document.getElementById('score').value = score;
		document.getElementById('thescore').value = score;
		document.getElementById('scorelbl').innerHTML = score;
		document.getElementById('submitbtn').style = 'display:none';
		
		var ans = document.getElementsByClassName('ans');
		for(i = 0; i!=ans.length;i++){
			ans[i].style='display:block';
		}
		
		document.getElementById('submit').style="display:block";
	}
</script>
</body>
</html>