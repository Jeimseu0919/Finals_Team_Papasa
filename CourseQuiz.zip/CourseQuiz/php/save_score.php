<?php

        include 'database.php';
		$name = $_POST['thenamae'];
		$score = $_POST['thescore'];
		$query = "INSERT INTO score (name, score) VALUES (".$name.",".$score.")";
		$conn->query($query);
		
		echo '<form action="quiz.php" method="post">';
		echo '<input type="hidden" value>';
		echo '</form>';
		
		

	
		





?>