<?php
    include 'database.php';
    if(isset($_POST['js_mc'])) {
        $query = "SELECT * FROM js_mc";
        $result = $conn->query($query);
        if($result->num_rows > 0) {
            while($data = mysqli_fetch_assoc($result)) {
                $id = $data['id'];
                $question = $data['question'];
                $answer1 = $data['answer1'];
                $answer2 = $data['answer2'];
                $answer3 = $data['answer3'];
                $correct_answer = $data['correct_answer'];

                echo "<table class='table'>";
                echo "<thead>";
                echo "<tr class='danger'>";
                echo "<th>".$num.'.&nbsp;&nbsp;'.$question."</th>";
                echo "</tr>";
                echo "</thead>";
                echo "<tbody>";
                if (isset($answer1)) {
                echo "<tr class='info'>";
                echo "<td><input type='radio' value='1' name=".$id.">&nbsp;&nbsp;&nbsp;".$answer1."</td>";
                echo "</tr>";
                }
    
                if (isset($answer1)) {
                echo "<tr class='info'>";
                echo "<td><input type='radio' value='2' name=".$id.">&nbsp;&nbsp;&nbsp;".$answer2."</td>";
                echo "</tr>";
                }
    
                if (isset($answer1)) {
                echo "<tr class='info'>";
                echo "<td><input type='radio' value='3' name=".$id.">&nbsp;&nbsp;&nbsp;".$answer3."</td>";
                echo "</tr>";
                }
    
                echo "<tr class='info'>";
                echo "<td><input type='radio' checked='checked' style='display: none !important;' value='no_answer' name=".$id."></td>"; 
                echo "</tr>";
    
                echo "</tbody>";
                echo "</table>";
                $num++;
            }
        }
    }
?>