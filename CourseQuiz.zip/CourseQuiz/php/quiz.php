<?php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>MyQuiz</title>
    <link rel="stylesheet" href="../css/main.css">
</head>
<body>
<div class="navbar">
	<h3 class="center">MyQuiz</h3>
</div>
<form method="POST" action="show_quiz.php">
<?php 
	if (isset($_POST['submit'])) {
        $user = $_POST['user'];
		$category = $_POST['category'];
	if($category == "http") {
	echo '
	<h1 class="center">'.$category.'</h1>
	<h5 class="center">hypertext transfer protocol</h5>
	<div class="card">
		<div class="card-item">
			<div class="card-body">
				<h2 class="card-title center" name="name" value="'.$user.'">'.$user.'</h2>
				<p class="card-text"></p>
				<div class="card-footer center">
					<a class="start" href="../index.php">Exit</a>
				</div>
			</div>
		</div>
		<div class="card-item">
			<div class="card-body">
				<h2 class="card-title center">Multiple Choice</h2>
				<p class="card-text">Details or reviewer for the quiz.</p>
				<div class="card-footer center">
					<input type="submit" role="button" class="start" name="http_mc" value="Start">
				</div>
			</div>
		</div>
		<div class="card-item">
			<div class="card-body">
				<h2 class="card-title center">Acronyms</h2>
				<p class="card-text">Details or reviewer for the quiz.</p>
				<div class="card-footer center">
					<input type="submit" role="button" class="start" name="http_ac" value="Start">
				</div>
			</div>
		</div>
		<div class="card-item">
			<div class="card-body">
				<h2 class="card-title center">True or False</h2>
				<p class="card-text">Details or reviewer for the quiz.</p>
				<div class="card-footer center">
					<input type="submit" role="button" class="start" name="http_tf" value="Start">
				</div>
			</div>
		</div>
		<div class="card-item">
			<div class="card-body">
				<h2 class="card-title center">Identification Test</h2>
				<p class="card-text">Details or reviewer for the quiz.</p>
				<div class="card-footer center">
					<input type="submit" role="button" class="start" name="http_id" value="Start">
				</div>
			</div>
		</div>
		<div class="card-item">
			<div class="card-body">
				<h2 class="card-title center">Matching Type</h2>
				<p class="card-text">Details or reviewer for the quiz.</p>
				<div class="card-footer center">
					<input type="submit" role="button" class="start" name="http_mt" value="Start">
				</div>
			</div>
		</div>
	</div>';
	}

	if($category == "html") {
	echo '<h1 class="center">'.$category.'</h1>
	<h5 class="center">hypertext markup language</h5>
	<div class="card">
	        <div class="card-item">
			<div class="card-body">
				<h2 class="card-title center">'.$user.'</h2>
				<input type="hidden" value="'.$user.'" name="user">
				<p class="card-text"></p>
				<div class="card-footer center">
					<a class="start" href="../index.php">Exit</a>
				</div>
			</div>
		</div>
		<div class="card-item">
			<div class="card-body">
				<h2 class="card-title center">Multiple Choice</h2>
				<p class="card-text">Details or reviewer for the quiz.</p>
				<div class="card-footer center">
					<input type="submit" role="button" class="start" name="html_mc" value="Start">
				</div>
			</div>
		</div>
		<div class="card-item">
			<div class="card-body">
				<h2 class="card-title center">Acronyms</h2>
				<p class="card-text">Details or reviewer for the quiz.</p>
				<div class="card-footer center">
					<input type="submit" role="button" class="start" name="html_ac" value="Start">
				</div>
			</div>
		</div>
		<div class="card-item">
			<div class="card-body">
				<h2 class="card-title center">True or False</h2>
				<p class="card-text">Details or reviewer for the quiz.</p>
				<div class="card-footer center">
					<input type="submit" role="button" class="start" name="html_tf" value="Start">
				</div>
			</div>
		</div>
		<div class="card-item">
			<div class="card-body">
				<h2 class="card-title center">Identification Test</h2>
				<p class="card-text">Details or reviewer for the quiz.</p>
				<div class="card-footer center">
					<input type="submit" role="button" class="start" name="html_id" value="Start">
				</div>
			</div>
		</div>
		<div class="card-item">
			<div class="card-body">
				<h2 class="card-title center">Matching Type</h2>
				<p class="card-text">Details or reviewer for the quiz.</p>
				<div class="card-footer center">
					<input type="submit" role="button" class="start" name="html_mt" value="Start">
				</div>
			</div>
		</div>
	</div>';
	}

	if($category == "css") {
	echo '<h1 class="center">'.$category.'</h1>
	<h5 class="center">cascading style sheets</h5>
	<div class="card">
	        <div class="card-item">
			<div class="card-body">
				<h2 class="card-title center">'.$user.'</h2>
				<input type="hidden" value="'.$user.'" name="user">
				<p class="card-text"></p>
				<div class="card-footer center">
					<a class="start" href="../index.php">Exit</a>
				</div>
			</div>
		</div>
		<div class="card-item">
			<div class="card-body">
				<h2 class="card-title center">Multiple Choice</h2>
				<p class="card-text">Details or reviewer for the quiz.</p>
				<div class="card-footer center">
					<input type="submit" role="button" class="start" name="css_mc" value="Start">
				</div>
			</div>
		</div>
		<div class="card-item">
			<div class="card-body">
				<h2 class="card-title center">Acronyms</h2>
				<p class="card-text">Details or reviewer for the quiz.</p>
				<div class="card-footer center">
					<input type="submit" role="button" class="start" name="css_ac" value="Start">
				</div>
			</div>
		</div>
		<div class="card-item">
			<div class="card-body">
				<h2 class="card-title center">True or False</h2>
				<p class="card-text">Details or reviewer for the quiz.</p>
				<div class="card-footer center">
					<input type="submit" role="button" class="start" name="css_tf" value="Start">
				</div>
			</div>
		</div>
		<div class="card-item">
			<div class="card-body">
				<h2 class="card-title center">Identification Test</h2>
				<p class="card-text">Details or reviewer for the quiz.</p>
				<div class="card-footer center">
					<input type="submit" role="button" class="start" name="css_id" value="Start">
				</div>
			</div>
		</div>
		<div class="card-item">
			<div class="card-body">
				<h2 class="card-title center">Matching Type</h2>
				<p class="card-text">Details or reviewer for the quiz.</p>
				<div class="card-footer center">
					<input type="submit" role="button" class="start" name="css_mt" value="Start">
				</div>
			</div>
		</div>
	</div>';
	}

	if($category == "javascript") {
	echo '<h1 class="center">'.$category.'</h1>
	<div class="card">
	        <div class="card-item">
			<div class="card-body">
				<h2 class="card-title center">'.$user.'</h2>
				<input type="hidden" value="'.$user.'" name="name">
				<p class="card-text"></p>
				<div class="card-footer center">
					<a class="start" href="../index.php">Exit</a>
				</div>
			</div>
		</div>
		<div class="card-item">
			<div class="card-body">
				<h2 class="card-title center">Multiple Choice</h2>
				<p class="card-text">Details or reviewer for the quiz.</p>
				<div class="card-footer center">
					<input type="submit" role="button" class="start" name="js_mc" value="Start">
				</div>
			</div>
		</div>
		<div class="card-item">
			<div class="card-body">
				<h2 class="card-title center">Acronyms</h2>
				<p class="card-text">Details or reviewer for the quiz.</p>
				<div class="card-footer center">
					<input type="submit" role="button" class="start" name="js_ac" value="Start">
				</div>
			</div>
		</div>
		<div class="card-item">
			<div class="card-body">
				<h2 class="card-title center">True or False</h2>
				<p class="card-text">Details or reviewer for the quiz.</p>
				<div class="card-footer center">
					<input type="submit" role="button" class="start" name="js_tf" value="Start">
				</div>
			</div>
		</div>
		<div class="card-item">
			<div class="card-body">
				<h2 class="card-title center">Identification Test</h2>
				<p class="card-text">Details or reviewer for the quiz.</p>
				<div class="card-footer center">
					<input type="submit" role="button" class="start" name="js_id" value="Start">
				</div>
			</div>
		</div>
		<div class="card-item">
			<div class="card-body">
				<h2 class="card-title center">Matching Type</h2>
				<p class="card-text">Details or reviewer for the quiz.</p>
				<div class="card-footer center">
					<input type="submit" role="button" class="start" name="js_mt" value="Start">
				</div>
			</div>
		</div>
	</div>';
	}

	if($category == "php") {
	echo '<h1 class="center">'.$category.'</h1>
	<h5 class="center">hypertext pre-processor</h5>
	<div class="card">
	        <div class="card-item">
			<div class="card-body">
				<h2 class="card-title center">'.$user.'</h2>
				<input type="hidden" value="'.$user.'" name="user">
				<p class="card-text"></p>
				<div class="card-footer center">
					<a class="start" href="../index.php">Exit</a>
				</div>
			</div>
		</div>
		<div class="card-item">
			<div class="card-body">
				<h2 class="card-title center">'.$user.'</h2>
				<p class="card-text"></p>
				<div class="card-footer center">
					<a class="start" href="../index.php">Exit</a>
				</div>
			</div>
		</div>
		<div class="card-item">
			<div class="card-body">
				<h2 class="card-title center">Multiple Choice</h2>
				<p class="card-text">Details or reviewer for the quiz.</p>
				<div class="card-footer center">
					<input type="submit" role="button" class="start" name="php_mc" value="Start">
				</div>
			</div>
		</div>
		<div class="card-item">
			<div class="card-body">
				<h2 class="card-title center">Acronyms</h2>
				<p class="card-text">Details or reviewer for the quiz.</p>
				<div class="card-footer center">
					<input type="submit" role="button" class="start" name="php_ac" value="Start">
				</div>
			</div>
		</div>
		<div class="card-item">
			<div class="card-body">
				<h2 class="card-title center">True or False</h2>
				<p class="card-text">Details or reviewer for the quiz.</p>
				<div class="card-footer center">
					<input type="submit" role="button" class="start" name="php_tf" value="Start">
				</div>
			</div>
		</div>
		<div class="card-item">
			<div class="card-body">
				<h2 class="card-title center">Identification Test</h2>
				<p class="card-text">Details or reviewer for the quiz.</p>
				<div class="card-footer center">
					<input type="submit" role="button" class="start" name="php_id" value="Start">
				</div>
			</div>
		</div>
		<div class="card-item">
			<div class="card-body">
				<h2 class="card-title center">Matching Type</h2>
				<p class="card-text">Details or reviewer for the quiz.</p>
				<div class="card-footer center">
					<input type="submit" role="button" class="start" name="php_mt" value="Start">
				</div>
			</div>
		</div>
	</div>';
	}
	}
	?>
</form>
</body>
</html>